/**
 * Created by xiewangzhi on 26/02/2018.
 */
const aboutData = {
  "name": "Wangzhi Xie",
  "cwid": "10422300",
  "biography": "I am a student in Stevens Institute of Technology majoring in Computer Engineering. I like sleeping in my spare time.(\n)",
  "favoriteShows": ["Stranger Things", "Game of Thrones", "Friends", "Ellen Show"],
  "hobbies": ["Sleep", "Sleep", "Sleep"]
};

const storyData = {
  "storyTitle": "That Time I Overreacted and Bought a Macbook",
  "story": "That summer break, my roommate always told me that Macbook is incredible and I should give it a shot. I felt a little crazy because it would cost me one thousand dollars, which is abunch of money for me. I hesitated for several days.\n" +
  "In the end, I made a difficult decision. I emptied my pocket and bought a Macbook."
};

const educationData = [
  {
    "schoolName": "Stevens Institute of Technology",
    "degree": "Master of Engineering",
    "favoriteClass": "Web Programming",
    "favoriteMemory": "Every Friday morning, I need to get up very early to attend this class. Unfortunately, I was late for several times."
  },
  {
    "schoolName": "China University",
    "degree": "Bachelor",
    "favoriteClass": "C Programming",
    "favoriteMemory": "Get to know a lovely girl."
  },
  {
    "schoolName": "Hogwarts School",
    "degree": "Wizard",
    "favoriteClass": "Ride on Besom",
    "favoriteMemory": "Get to know Harry Porter"
  }
];

module.exports = {
  about: aboutData,
  story: storyData,
  education: educationData
};



