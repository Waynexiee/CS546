/**
 * Created by xiewangzhi on 07/03/2018.
 */
const recipeData = require("./recipes");

module.exports = {
  recipes: recipeData,
};

